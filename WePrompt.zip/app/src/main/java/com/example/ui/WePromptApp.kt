package com.example.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.PromptItem
import com.example.data.PromptRepository
import com.example.ui.components.NavigationTab
import com.example.ui.components.WePromptBottomNavBar
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun WePromptApp(
    repository: PromptRepository
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var isSplashActive by remember { mutableStateOf(true) }
    var currentTab by remember { mutableStateOf(NavigationTab.HOME) }
    var selectedPromptItem by remember { mutableStateOf<PromptItem?>(null) }
    var isSearchOpen by remember { mutableStateOf(false) }
    var showExitDialog by remember { mutableStateOf(false) }

    val favoriteIds by repository.favoriteIds.collectAsState()
    val appConfig by repository.appConfig.collectAsState()

    if (isSplashActive) {
        SplashScreen(
            repository = repository,
            onFinished = {
                isSplashActive = false
            }
        )
    } else if (appConfig.maintenanceMode) {
        MaintenanceScreen(
            message = appConfig.maintenanceMessage,
            onRetry = {
                scope.launch {
                    repository.loadAppConfig()
                }
            }
        )
    } else if (selectedPromptItem != null) {
        val item = selectedPromptItem!!
        PreviewPromptScreen(
            initialItem = item,
            repository = repository,
            appConfig = appConfig,
            isFavorite = favoriteIds.contains(item.id),
            onFavoriteToggle = { toggled -> repository.toggleFavorite(toggled) },
            onBack = { selectedPromptItem = null }
        )
    } else {
        // Back navigation: on non-Home tabs return to Home; on Home screen show custom Exit Confirmation dialog
        if (currentTab != NavigationTab.HOME) {
            BackHandler {
                currentTab = NavigationTab.HOME
            }
        } else if (!isSearchOpen) {
            BackHandler {
                showExitDialog = true
            }
        }

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = BackgroundDark,
            bottomBar = {
                WePromptBottomNavBar(
                    currentTab = currentTab,
                    onTabSelected = { currentTab = it }
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentTab) {
                    NavigationTab.HOME -> {
                        HomeScreen(
                            repository = repository,
                            onPromptClick = { selectedPromptItem = it },
                            onSearchClick = { isSearchOpen = true }
                        )
                    }
                    NavigationTab.DAILY -> {
                        DailyUpdateScreen(
                            repository = repository,
                            onPromptClick = { selectedPromptItem = it }
                        )
                    }
                    NavigationTab.FAVOURITE -> {
                        FavouriteScreen(
                            repository = repository,
                            onPromptClick = { selectedPromptItem = it }
                        )
                    }
                    NavigationTab.MENU -> {
                        MenuScreen()
                    }
                }

                if (isSearchOpen) {
                    SearchDialog(
                        repository = repository,
                        onPromptClick = { item ->
                            selectedPromptItem = item
                        },
                        onDismiss = { isSearchOpen = false }
                    )
                }

                if (showExitDialog) {
                    ExitConfirmationDialog(
                        onConfirmExit = {
                            showExitDialog = false
                            (context as? Activity)?.finish()
                        },
                        onDismiss = {
                            showExitDialog = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ExitConfirmationDialog(
    onConfirmExit: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 360.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(SurfaceDark)
                    .border(1.dp, SurfaceBorder, RoundedCornerShape(22.dp))
                    .padding(horizontal = 22.dp, vertical = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ExitToApp,
                    contentDescription = null,
                    tint = AccentMagenta,
                    modifier = Modifier.size(36.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Exit WePrompt?",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = TextPrimary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Are you sure you want to exit?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Outlined box right below the text containing centered side-by-side No (Grey) & Yes (Red) buttons
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceCard.copy(alpha = 0.55f))
                        .border(1.dp, SurfaceBorder, RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = DialogGreyButton),
                            shape = RoundedCornerShape(50.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("exit_dialog_no")
                        ) {
                            Text("No", color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onConfirmExit,
                            colors = ButtonDefaults.buttonColors(containerColor = DialogRedButton),
                            shape = RoundedCornerShape(50.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("exit_dialog_yes")
                        ) {
                            Text("Yes", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MaintenanceScreen(
    message: String,
    onRetry: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(SurfaceDark)
                .border(1.dp, SurfaceBorder, RoundedCornerShape(24.dp))
                .padding(28.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Build,
                contentDescription = null,
                tint = AccentCyan,
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Under Maintenance",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                shape = RoundedCornerShape(50.dp)
            ) {
                Text("Check Again", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}
