package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.util.AppLauncher

private const val PRIVACY_POLICY_URL = "https://weprompt.wegocup.com/privacy-policy/"
private const val TERMS_OF_SERVICE_URL = "https://weprompt.wegocup.com/terms-of-service/"
private const val ABOUT_US_URL = "https://weprompt.wegocup.com/about-us/"
private const val SUPPORT_EMAIL = "Support.WePrompt@gmail.com"

@Composable
fun MenuScreen(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(bottom = 84.dp)
    ) {
        // Menu Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceDark)
                    .border(1.dp, SurfaceBorder, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = null,
                    tint = AccentCyan,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = "Menu & Compliance",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = TextPrimary
                )
                Text(
                    text = "Legal pages, support, and sharing",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        CardSectionTitle(title = "LEGAL & COMPLIANCE")

        MenuItemCard(
            title = "Privacy Policy",
            subtitle = "Read our privacy policy online",
            icon = Icons.Outlined.Security,
            iconTint = AccentCyan,
            testTag = "menu_privacy_policy",
            onClick = { AppLauncher.openWebUrl(context, PRIVACY_POLICY_URL) }
        )

        MenuItemCard(
            title = "Terms of Service",
            subtitle = "View rules and terms of service",
            icon = Icons.Outlined.Description,
            iconTint = AccentPurple,
            testTag = "menu_terms",
            onClick = { AppLauncher.openWebUrl(context, TERMS_OF_SERVICE_URL) }
        )

        MenuItemCard(
            title = "About Us",
            subtitle = "Learn more about WePrompt",
            icon = Icons.Outlined.Info,
            iconTint = AccentMagenta,
            testTag = "menu_about_us",
            onClick = { AppLauncher.openWebUrl(context, ABOUT_US_URL) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        CardSectionTitle(title = "SUPPORT & ENGAGEMENT")

        MenuItemCard(
            title = "Contact Us",
            subtitle = SUPPORT_EMAIL,
            icon = Icons.Outlined.Email,
            iconTint = Color(0xFF64FFDA),
            testTag = "menu_contact_us",
            onClick = { AppLauncher.openEmail(context, SUPPORT_EMAIL) }
        )

        MenuItemCard(
            title = "Rate Us",
            subtitle = "Leave a 5-star review on Google Play",
            icon = Icons.Outlined.Star,
            iconTint = Color(0xFFFFD166),
            testTag = "menu_rate_us",
            onClick = { AppLauncher.openRateUs(context) }
        )

        MenuItemCard(
            title = "Share App",
            subtitle = "Share WePrompt with friends & creators",
            icon = Icons.Outlined.Share,
            iconTint = AccentPink,
            testTag = "menu_share_app",
            onClick = {
                AppLauncher.shareText(
                    context = context,
                    text = "Check out WePrompt - AI Photo & Video prompt generator! Create magic with ChatGPT, Gemini, and Google Flow: https://play.google.com/store/apps/details?id=${context.packageName}",
                    title = "Share WePrompt"
                )
            }
        )

        Spacer(modifier = Modifier.height(24.dp))

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "WePrompt v1.0.0",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                color = TextSecondary
            )
            Text(
                text = "Crafted for AI creators worldwide",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = TextMuted
            )
        }
    }
}

@Composable
private fun CardSectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.labelMedium.copy(
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        ),
        color = TextSecondary,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
    )
}

@Composable
private fun MenuItemCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceDark)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(14.dp))
            .clickable(
                indication = ripple(color = Color.White),
                interactionSource = remember { MutableInteractionSource() },
                onClick = onClick
            )
            .padding(14.dp)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = TextPrimary
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(14.dp)
            )
        }
    }
}
