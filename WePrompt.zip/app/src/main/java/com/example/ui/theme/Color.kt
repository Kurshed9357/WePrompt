package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Exact Theme Colors Requested
val BackgroundDark = Color(0xFF10051F)   // Primary #10051F
val SurfaceDark = Color(0xFF24083D)      // Secondary #24083D
val SurfaceCard = Color(0xFF100D2D)      // Third #100D2D
val SurfaceBorder = Color(0xFF391C5C)    // Subtle Accent Border
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFB8A9D4)
val TextMuted = Color(0xFF7D6B9E)

// Accent Colors
val AccentCyan = Color(0xFF64FFDA)
val AccentPurple = Color(0xFF8000A8)
val AccentMagenta = Color(0xFFD00083)
val AccentDeepPurple = Color(0xFF3B00B5)
val AccentPink = Color(0xFFFF2A85)
val FavoriteRed = Color(0xFFFF3366)
val DialogGreyButton = Color(0xFF5A6270)
val DialogRedButton = Color(0xFFE53935)

// Specific Linear Gradient at 90deg: #3B00B5 (0%), #8000A8 (52%), to #D00083 (100%)
val GenerateButtonGradient = Brush.horizontalGradient(
    0.0f to Color(0xFF3B00B5),
    0.52f to Color(0xFF8000A8),
    1.0f to Color(0xFFD00083)
)

// Category Gradients
val CategoryActiveGradient = Brush.horizontalGradient(
    listOf(Color(0xFF3B00B5), Color(0xFF8000A8), Color(0xFFD00083))
)

val CategoryInactiveGradient = Brush.horizontalGradient(
    listOf(Color(0xFF24083D), Color(0xFF100D2D))
)

// App Integration Gradients
val ChatGPTGradient = Brush.horizontalGradient(
    listOf(Color(0xFF10A37F), Color(0xFF0D8A6C))
)

val GeminiGradient = Brush.horizontalGradient(
    listOf(Color(0xFF1B72E8), Color(0xFF8E24AA))
)

val GoogleFlowGradient = Brush.horizontalGradient(
    listOf(Color(0xFFFF5E62), Color(0xFFFF9966))
)

val CopyButtonGradient = Brush.horizontalGradient(
    listOf(Color(0xFF00C9FF), Color(0xFF92FE9D))
)
