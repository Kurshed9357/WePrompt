package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.CategoryItem
import com.example.data.PromptItem
import com.example.data.PromptRepository
import com.example.ui.components.DynamicCategorySelector
import com.example.ui.components.LoadingSkeletonGrid
import com.example.ui.components.PromptGridCard
import com.example.ui.components.WePromptTopHeader
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    repository: PromptRepository,
    onPromptClick: (PromptItem) -> Unit,
    onSearchClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val favoriteIds by repository.favoriteIds.collectAsState()

    var categories by remember { mutableStateOf<List<CategoryItem>>(emptyList()) }
    var categoriesLoading by remember { mutableStateOf(true) }
    var selectedCategoryId by remember { mutableStateOf("") }

    var prompts by remember { mutableStateOf<List<PromptItem>>(emptyList()) }
    var isInitialLoading by remember { mutableStateOf(true) }
    var isRefreshing by remember { mutableStateOf(false) }
    var isLoadingMore by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var paginationError by remember { mutableStateOf<String?>(null) }
    var currentPage by remember { mutableIntStateOf(1) }
    var hasMorePages by remember { mutableStateOf(true) }
    var activeRequestToken by remember { mutableIntStateOf(0) }

    val gridState = rememberLazyGridState()

    fun loadPage(page: Int, isRefresh: Boolean = false) {
        val targetCategoryId = selectedCategoryId
        val requestToken = if (page == 1) {
            activeRequestToken + 1
        } else {
            activeRequestToken
        }
        if (page == 1) {
            activeRequestToken = requestToken
        }

        scope.launch {
            if (page == 1) {
                if (isRefresh) {
                    isRefreshing = true
                } else {
                    isRefreshing = false
                    isInitialLoading = true
                }
                errorMessage = null
                paginationError = null
            } else {
                isLoadingMore = true
                paginationError = null
            }

            val catArg = if (targetCategoryId.isBlank() || targetCategoryId == "__fallback__") {
                null
            } else {
                targetCategoryId
            }
            val selectedCategoryName = categories.find { it.id == targetCategoryId }?.name

            val result = repository.getPrompts(
                page = page,
                categoryId = catArg,
                isRefresh = isRefresh
            )

            // Ignore stale responses if the user switched categories while loading
            if (targetCategoryId != selectedCategoryId || requestToken != activeRequestToken) {
                return@launch
            }

            result.onSuccess { rawFetched ->
                val fetched = if (!selectedCategoryName.isNullOrBlank()) {
                    rawFetched.map { item ->
                        if (item.categoryName.isBlank() || item.categoryName == "Trending Photos") {
                            item.copy(categoryName = selectedCategoryName)
                        } else {
                            item
                        }
                    }
                } else {
                    rawFetched
                }

                if (page == 1) {
                    prompts = fetched
                } else {
                    val existingIds = prompts.map { it.id }.toSet()
                    val uniqueNew = fetched.filter { !existingIds.contains(it.id) }
                    prompts = prompts + uniqueNew
                }
                currentPage = page
                hasMorePages = rawFetched.size >= 20
                errorMessage = null
                paginationError = null
            }.onFailure { err ->
                if (page == 1 && prompts.isEmpty()) {
                    errorMessage = err.message ?: "Unable to connect to WePrompt server."
                } else if (page > 1) {
                    paginationError = err.message ?: "Failed to load more prompts."
                }
            }

            isInitialLoading = false
            isRefreshing = false
            isLoadingMore = false
        }
    }

    fun loadCategories(triggerFallbackReload: Boolean = false) {
        scope.launch {
            categoriesLoading = true
            repository.getCategories().onSuccess { fetched ->
                categories = fetched
                if ((selectedCategoryId.isBlank() || selectedCategoryId == "__fallback__") && fetched.isNotEmpty()) {
                    selectedCategoryId = fetched.first().id
                } else if (selectedCategoryId.isNotBlank()) {
                    loadPage(page = 1, isRefresh = true)
                }
            }.onFailure {
                if (selectedCategoryId.isBlank()) {
                    // Trigger fallback load of page 1 if categories endpoint failed
                    selectedCategoryId = "__fallback__"
                } else if (triggerFallbackReload) {
                    loadPage(page = 1, isRefresh = true)
                }
            }
            categoriesLoading = false
        }
    }

    // Initial load
    LaunchedEffect(Unit) {
        loadCategories()
    }

    // Reload prompts whenever selected category changes
    LaunchedEffect(selectedCategoryId) {
        if (selectedCategoryId.isNotBlank()) {
            hasMorePages = true
            currentPage = 1
            loadPage(page = 1, isRefresh = false)
        }
    }

    // Detect bottom of grid for pagination
    val shouldLoadMore by remember {
        derivedStateOf {
            val layoutInfo = gridState.layoutInfo
            val totalItems = layoutInfo.totalItemsCount
            val lastVisible = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            totalItems > 0 && lastVisible >= totalItems - 4
        }
    }

    LaunchedEffect(shouldLoadMore, isInitialLoading, isLoadingMore, isRefreshing, hasMorePages, currentPage, paginationError) {
        if (shouldLoadMore && !isInitialLoading && !isLoadingMore && !isRefreshing && hasMorePages && paginationError == null) {
            loadPage(page = currentPage + 1, isRefresh = false)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundDark)
            .statusBarsPadding()
    ) {
        WePromptTopHeader(onSearchClick = onSearchClick)

        DynamicCategorySelector(
            categories = categories,
            selectedCategoryId = selectedCategoryId,
            onCategorySelected = { newId ->
                if (selectedCategoryId != newId) {
                    selectedCategoryId = newId
                    prompts = emptyList()
                    paginationError = null
                }
            },
            isLoading = categoriesLoading
        )

        Spacer(modifier = Modifier.height(6.dp))

        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = {
                if (categories.isEmpty() || selectedCategoryId == "__fallback__") {
                    loadCategories(triggerFallbackReload = true)
                } else {
                    loadCategories(triggerFallbackReload = false)
                }
            },
            modifier = Modifier.fillMaxSize()
        ) {
            when {
                isInitialLoading && prompts.isEmpty() -> {
                    LoadingSkeletonGrid()
                }
                errorMessage != null && prompts.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.CloudOff,
                                contentDescription = null,
                                tint = AccentMagenta,
                                modifier = Modifier.size(56.dp)
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Could Not Load Prompts",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = errorMessage ?: "Please check your internet connection.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(18.dp))
                            Button(
                                onClick = {
                                    if (categories.isEmpty() || selectedCategoryId == "__fallback__") {
                                        loadCategories(triggerFallbackReload = true)
                                    } else {
                                        loadPage(page = 1, isRefresh = true)
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                                shape = RoundedCornerShape(50.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Retry", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                prompts.isEmpty() -> {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No prompts available in this category.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
                else -> {
                    LazyVerticalGrid(
                        state = gridState,
                        columns = GridCells.Fixed(2),
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("home_prompt_grid"),
                        contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 84.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        itemsIndexed(prompts, key = { _, it -> it.id }) { index, item ->
                            PromptGridCard(
                                item = item,
                                isFavorite = favoriteIds.contains(item.id),
                                onFavoriteClick = { repository.toggleFavorite(item) },
                                onClick = { onPromptClick(item) },
                                index = index,
                                modifier = Modifier.animateItem()
                            )
                        }

                        if (isLoadingMore) {
                            item(span = { GridItemSpan(2) }) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(
                                        color = AccentMagenta,
                                        modifier = Modifier.size(28.dp),
                                        strokeWidth = 3.dp
                                    )
                                }
                            }
                        } else if (paginationError != null) {
                            item(span = { GridItemSpan(2) }) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = paginationError!!,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedButton(
                                        onClick = { loadPage(page = currentPage + 1, isRefresh = false) },
                                        shape = RoundedCornerShape(50.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Refresh,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Retry More")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
