package com.example.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object AppLauncher {

    const val CHATGPT_PACKAGE = "com.openai.chatgpt"
    const val CHATGPT_URL = "https://play.google.com/store/apps/details?id=com.openai.chatgpt"

    const val GEMINI_PACKAGE = "com.google.android.apps.bard"
    const val GEMINI_URL = "https://play.google.com/store/apps/details?id=com.google.android.apps.bard"

    const val GOOGLE_FLOW_PACKAGE = "com.google.android.apps.labs.whisk"
    const val GOOGLE_FLOW_URL = "https://play.google.com/store/apps/details?id=com.google.android.apps.labs.whisk"

    fun copyToClipboard(context: Context, text: String, showToast: Boolean = true) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("WePrompt AI Prompt", text)
        clipboard.setPrimaryClip(clip)
        if (showToast) {
            Toast.makeText(context, "Prompt copied to clipboard!", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchAppWithPrompt(
        context: Context,
        appName: String,
        packageName: String,
        playStoreUrl: String,
        prompt: String
    ) {
        // 1. Always copy prompt to clipboard so it's guaranteed ready
        copyToClipboard(context, prompt, showToast = false)
        Toast.makeText(context, "Prompt copied! Opening $appName...", Toast.LENGTH_SHORT).show()

        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName)

        if (launchIntent != null) {
            // Attempt ACTION_SEND with package to auto-fill the prompt
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, prompt)
                setPackage(packageName)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(sendIntent)
                return
            } catch (e: Exception) {
                // Fallback to basic launch intent with extra text
                try {
                    launchIntent.putExtra(Intent.EXTRA_TEXT, prompt)
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return
                } catch (e2: Exception) {
                    // fallthrough to market
                }
            }
        }

        // Open in Google Play Store or Browser
        try {
            val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(marketIntent)
        } catch (e: Exception) {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(playStoreUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(browserIntent)
        }
    }

    fun openPlayStoreUrl(context: Context, url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open link", Toast.LENGTH_SHORT).show()
        }
    }

    fun openRateUs(context: Context) {
        val pkg = context.packageName
        try {
            val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(marketIntent)
        } catch (e: Exception) {
            openWebUrl(context, "https://play.google.com/store/apps/details?id=$pkg")
        }
    }

    fun openWebUrl(context: Context, url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "No browser app found to open link", Toast.LENGTH_SHORT).show()
        }
    }

    fun openEmail(context: Context, email: String, subject: String = "WePrompt Support") {
        val mailUri = Uri.parse("mailto:$email?subject=${Uri.encode(subject)}")
        val emailIntent = Intent(Intent.ACTION_SENDTO, mailUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(emailIntent)
        } catch (e: Exception) {
            copyToClipboard(context, email, showToast = false)
            Toast.makeText(context, "No email app found. Copied $email", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareText(context: Context, text: String, title: String = "Share WePrompt") {
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, text)
            type = "text/plain"
        }
        val shareIntent = Intent.createChooser(sendIntent, title).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(shareIntent)
    }
}
