package com.example.data

data class CategoryItem(
    val id: String,
    val name: String,
    val slug: String = ""
)

data class AppConfig(
    val maintenanceMode: Boolean = false,
    val maintenanceMessage: String = "WePrompt is undergoing scheduled maintenance. Please check back soon.",
    val globalVideoEnabled: Boolean = true,
    val autoPlayVideos: Boolean = true
)

data class PromptItem(
    val id: String,
    val title: String,
    val categoryId: String = "",
    val categoryName: String = "AI Prompt",
    val modelName: String = "AI Model",
    val imageUrl: String = "",
    val videoUrl: String? = null,
    val isVideo: Boolean = false,
    val promptText: String = "",
    val isDailyUpdate: Boolean = false,
    val viewsCount: Int = 10000,
    val aspectRatio: Float = 0.78f
)

sealed class UiState<out T> {
    data object Loading : UiState<Nothing>()
    data class Success<T>(val data: T) : UiState<T>()
    data class Error(val message: String) : UiState<Nothing>()
}
