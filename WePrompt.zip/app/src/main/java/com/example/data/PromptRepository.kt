package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.random.Random

class PromptRepository(
    context: Context,
    private val apiClient: WePromptApiClient = WePromptApiClient()
) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("weprompt_prefs", Context.MODE_PRIVATE)

    private val _favoriteIds = MutableStateFlow<Set<String>>(loadFavorites())
    val favoriteIds: StateFlow<Set<String>> = _favoriteIds.asStateFlow()

    private val _favoriteItemsMap = MutableStateFlow<Map<String, PromptItem>>(loadFavoriteItems())
    val favoriteItems: StateFlow<List<PromptItem>> = MutableStateFlow(emptyList<PromptItem>()).also { flow ->
        flow.value = _favoriteItemsMap.value.values.toList()
    }

    private val _appConfig = MutableStateFlow(AppConfig())
    val appConfig: StateFlow<AppConfig> = _appConfig.asStateFlow()

    // Dynamic View Count tracking:
    // Initial range: 10,000 (10K) to 500,000 (500K)
    // Increment per refresh: 50 to 300
    // Hard cap: 1,000,000 (1M)
    private val viewCountsMap = mutableMapOf<String, Int>().apply {
        loadSavedViewCounts(this)
    }

    companion object {
        const val MIN_INITIAL_VIEWS = 10_000
        const val MAX_INITIAL_VIEWS = 500_000
        const val MIN_REFRESH_INCREMENT = 50
        const val MAX_REFRESH_INCREMENT = 300
        const val MAX_VIEW_CAP = 1_000_000

        fun formatViewCount(count: Int): String {
            val capped = count.coerceIn(0, MAX_VIEW_CAP)
            return when {
                capped >= MAX_VIEW_CAP -> "1M"
                capped >= 1_000 -> {
                    val kValue = capped / 1_000.0
                    if (capped % 1_000 < 100) {
                        "${capped / 1_000}K"
                    } else {
                        String.format(Locale.US, "%.1fK", kValue)
                    }
                }
                else -> capped.toString()
            }
        }
    }

    private fun loadFavorites(): Set<String> {
        return prefs.getStringSet("favorite_ids", emptySet()) ?: emptySet()
    }

    private fun loadFavoriteItems(): Map<String, PromptItem> {
        val raw = prefs.getString("favorite_items_json", null) ?: return emptyMap()
        val map = mutableMapOf<String, PromptItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val item = PromptItem(
                    id = obj.optString("id"),
                    title = obj.optString("title"),
                    categoryId = obj.optString("categoryId"),
                    categoryName = obj.optString("categoryName"),
                    modelName = obj.optString("modelName"),
                    imageUrl = obj.optString("imageUrl"),
                    videoUrl = obj.optString("videoUrl").ifBlank { null },
                    isVideo = obj.optBoolean("isVideo", false),
                    promptText = obj.optString("promptText"),
                    isDailyUpdate = obj.optBoolean("isDailyUpdate", false),
                    viewsCount = obj.optInt("viewsCount", 15_000)
                )
                if (item.id.isNotBlank()) {
                    map[item.id] = item
                }
            }
        } catch (_: Exception) {
        }
        return map
    }

    private fun saveFavoriteItems(map: Map<String, PromptItem>) {
        val arr = JSONArray()
        map.values.forEach { item ->
            arr.put(
                JSONObject().apply {
                    put("id", item.id)
                    put("title", item.title)
                    put("categoryId", item.categoryId)
                    put("categoryName", item.categoryName)
                    put("modelName", item.modelName)
                    put("imageUrl", item.imageUrl)
                    put("videoUrl", item.videoUrl ?: "")
                    put("isVideo", item.isVideo)
                    put("promptText", item.promptText)
                    put("isDailyUpdate", item.isDailyUpdate)
                    put("viewsCount", item.viewsCount)
                }
            )
        }
        prefs.edit().putString("favorite_items_json", arr.toString()).apply()
    }

    private fun loadSavedViewCounts(target: MutableMap<String, Int>) {
        val raw = prefs.getString("dynamic_view_counts", null) ?: return
        try {
            val obj = JSONObject(raw)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = obj.optInt(key, MIN_INITIAL_VIEWS).coerceIn(MIN_INITIAL_VIEWS, MAX_VIEW_CAP)
                target[key] = value
            }
        } catch (_: Exception) {
        }
    }

    private fun persistViewCounts() {
        val obj = JSONObject()
        viewCountsMap.forEach { (k, v) ->
            obj.put(k, v)
        }
        prefs.edit().putString("dynamic_view_counts", obj.toString()).apply()
    }

    /**
     * Assigns an initial random view count (10K-500K) if new, or increments by 50-300 if refreshing.
     * Strictly capped at 1M (1,000,000).
     */
    fun resolveDynamicViewCount(promptId: String, isRefresh: Boolean): Int {
        val current = viewCountsMap[promptId]
        val updated = if (current == null) {
            Random.nextInt(MIN_INITIAL_VIEWS, MAX_INITIAL_VIEWS + 1)
        } else if (isRefresh) {
            val increment = Random.nextInt(MIN_REFRESH_INCREMENT, MAX_REFRESH_INCREMENT + 1)
            (current + increment).coerceAtMost(MAX_VIEW_CAP)
        } else {
            current.coerceAtMost(MAX_VIEW_CAP)
        }
        viewCountsMap[promptId] = updated
        return updated
    }

    private fun applyViewCounts(items: List<PromptItem>, isRefresh: Boolean): List<PromptItem> {
        val result = items.map { item ->
            val views = resolveDynamicViewCount(item.id, isRefresh)
            item.copy(viewsCount = views)
        }
        persistViewCounts()
        return result
    }

    fun toggleFavorite(item: PromptItem) {
        val currentIds = _favoriteIds.value.toMutableSet()
        val currentMap = _favoriteItemsMap.value.toMutableMap()
        if (currentIds.contains(item.id)) {
            currentIds.remove(item.id)
            currentMap.remove(item.id)
        } else {
            currentIds.add(item.id)
            currentMap[item.id] = item
        }
        _favoriteIds.value = currentIds
        _favoriteItemsMap.value = currentMap
        prefs.edit().putStringSet("favorite_ids", currentIds).apply()
        saveFavoriteItems(currentMap)
    }

    fun isFavorite(id: String): Boolean = _favoriteIds.value.contains(id)

    fun getFavoriteItemsList(): List<PromptItem> {
        return _favoriteItemsMap.value.values.map { item ->
            item.copy(viewsCount = resolveDynamicViewCount(item.id, isRefresh = false))
        }
    }

    suspend fun loadAppConfig(): AppConfig {
        val result = apiClient.fetchAppConfig()
        val config = result.getOrElse { AppConfig() }
        _appConfig.value = config
        return config
    }

    suspend fun getCategories(): Result<List<CategoryItem>> {
        return apiClient.fetchCategories()
    }

    suspend fun getPrompts(
        page: Int,
        categoryId: String? = null,
        isRefresh: Boolean = false
    ): Result<List<PromptItem>> {
        return apiClient.fetchPrompts(
            page = page,
            limit = 20,
            categoryId = categoryId
        ).map { items ->
            applyViewCounts(items, isRefresh = isRefresh)
        }
    }

    suspend fun searchPrompts(query: String): Result<List<PromptItem>> {
        return apiClient.fetchPrompts(
            page = 1,
            limit = 40,
            searchQuery = query
        ).map { items ->
            applyViewCounts(items, isRefresh = false)
        }
    }

    suspend fun getPromptDetail(id: String): Result<PromptItem> {
        return apiClient.fetchPromptDetail(id).map { item ->
            item.copy(viewsCount = resolveDynamicViewCount(item.id, isRefresh = false))
        }
    }
}
