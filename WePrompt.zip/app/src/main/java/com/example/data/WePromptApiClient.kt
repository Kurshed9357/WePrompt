package com.example.data

import com.example.BuildConfig
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class WePromptApiClient {

    companion object {
        private const val BASE_URL = "https://prompt.wegocup.com/api/"
        private const val SITE_ROOT = "https://prompt.wegocup.com/"

        internal fun normalizeCategoryName(rawName: String, slug: String = ""): String {
            val trimmed = rawName.trim()
            val normalizedKey = trimmed.lowercase()
            val slugKey = slug.trim().lowercase()
            return when {
                normalizedKey == "trending photos" || normalizedKey == "tending photos" ||
                    normalizedKey == "trending photo" || normalizedKey == "tending photo" ||
                    slugKey == "trending-photos" || slugKey == "tending-photos" -> "Trending Photos"
                normalizedKey == "trending videos" || normalizedKey == "tending videos" ||
                    normalizedKey == "trending video" || normalizedKey == "tending video" ||
                    slugKey == "trending-videos" || slugKey == "tending-videos" -> "Trending Videos"
                normalizedKey == "boys" || normalizedKey == "boy" || slugKey == "boys" -> "Boys"
                normalizedKey == "girls" || normalizedKey == "girl" || slugKey == "girls" -> "Girls"
                else -> trimmed
            }
        }

        internal fun sortCategories(categories: List<CategoryItem>): List<CategoryItem> {
            val priorityOrder = listOf(
                "trending photos",
                "trending videos",
                "boys",
                "girls"
            )
            return categories.sortedWith(compareBy { cat ->
                val normalized = normalizeCategoryName(cat.name, cat.slug).lowercase()
                val idx = priorityOrder.indexOf(normalized)
                if (idx >= 0) idx else priorityOrder.size
            })
        }
    }

    private fun resolvedApiKey(): String {
        val raw = BuildConfig.WEPROMPT_API_KEY
            .trim()
            .removeSurrounding("\"")
            .removeSurrounding("'")
            .trim()
        return if (raw == "YOUR_CONFIGURED_API_KEY") "" else raw
    }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val apiKey = resolvedApiKey()
            val builder = chain.request().newBuilder()
                .header("Accept", "application/json")
            if (apiKey.isNotBlank()) {
                builder.header("X-API-Key", apiKey)
            }
            chain.proceed(builder.build())
        }
        .build()

    private fun extractServerErrorMessage(body: String): String {
        val trimmed = body.trim()
        if (trimmed.startsWith("{")) {
            try {
                val json = JSONObject(trimmed)
                val msg = optStringAny(json, "message", "error", "detail")
                if (msg.isNotBlank()) return msg
            } catch (_: Exception) {
            }
        }
        return ""
    }

    private suspend fun executeGet(endpoint: String): String = suspendCancellableCoroutine { cont ->
        val request = Request.Builder()
            .url("$BASE_URL$endpoint")
            .get()
            .build()

        val call = client.newCall(request)
        cont.invokeOnCancellation { call.cancel() }

        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) {
                    cont.resumeWithException(e)
                }
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { res ->
                    if (!cont.isActive) return
                    val body = res.body?.string().orEmpty()
                    if (!res.isSuccessful) {
                        val serverMsg = extractServerErrorMessage(body)
                        val error = when (res.code) {
                            401 -> IllegalStateException(
                                if (serverMsg.isNotBlank()) {
                                    "Unauthorized (401): $serverMsg"
                                } else {
                                    "Unauthorized (401): Backend requires X-API-Key or rejected authentication."
                                }
                            )
                            403 -> IllegalStateException(
                                if (serverMsg.isNotBlank()) {
                                    "Forbidden (403): $serverMsg"
                                } else {
                                    "Forbidden (403): Server or WAF blocked access to this endpoint."
                                }
                            )
                            else -> {
                                val detail = serverMsg.ifBlank { res.message.ifBlank { "Request failed" } }
                                IllegalStateException("Server error (${res.code}): $detail")
                            }
                        }
                        cont.resumeWithException(error)
                        return
                    }
                    if (body.isBlank()) {
                        cont.resumeWithException(IllegalStateException("Empty response from server"))
                        return
                    }
                    cont.resume(body)
                }
            }
        })
    }

    suspend fun fetchAppConfig(): Result<AppConfig> {
        return try {
            val raw = executeGet("app-config.php")
            val json = JSONObject(raw.trim())
            val obj = json.optJSONObject("data")
                ?: json.optJSONObject("config")
                ?: json

            val maintenanceMode = parseBool(obj, "maintenance_mode", "is_maintenance", "maintenance")
            val maintenanceMsg = optStringAny(obj, "maintenance_message", "message")
                .ifBlank { "WePrompt is currently under scheduled maintenance. Please check back shortly." }
            val globalVideo = if (hasAnyKey(obj, "allow_video", "global_video", "video_enabled", "enable_video", "is_video_enabled")) {
                parseBool(obj, "allow_video", "global_video", "video_enabled", "enable_video", "is_video_enabled")
            } else {
                true
            }
            val autoPlay = if (hasAnyKey(obj, "auto_play_video", "autoplay", "video_autoplay")) {
                parseBool(obj, "auto_play_video", "autoplay", "video_autoplay")
            } else {
                true
            }

            Result.success(
                AppConfig(
                    maintenanceMode = maintenanceMode,
                    maintenanceMessage = maintenanceMsg,
                    globalVideoEnabled = globalVideo,
                    autoPlayVideos = autoPlay
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchCategories(): Result<List<CategoryItem>> {
        return try {
            val raw = executeGet("categories.php").trim()
            val array = extractArray(raw, "categories", "data", "items", "results")
            val list = mutableListOf<CategoryItem>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val id = optStringAny(obj, "id", "category_id", "cat_id")
                val rawName = optStringAny(obj, "name", "category_name", "title")
                val slug = optStringAny(obj, "slug")
                val name = normalizeCategoryName(rawName, slug)
                val isAllCategory = name.trim().equals("all", ignoreCase = true) ||
                    id.trim().equals("all", ignoreCase = true)
                if (id.isNotBlank() && name.isNotBlank() && !isAllCategory) {
                    list.add(CategoryItem(id = id, name = name, slug = slug))
                }
            }
            Result.success(sortCategories(list))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchPrompts(
        page: Int = 1,
        limit: Int = 20,
        categoryId: String? = null,
        searchQuery: String? = null
    ): Result<List<PromptItem>> {
        return try {
            val endpoint = buildString {
                append("prompts.php?")
                if (!searchQuery.isNullOrBlank()) {
                    append("search=${URLEncoder.encode(searchQuery.trim(), "UTF-8")}")
                    append("&page=$page&limit=$limit")
                } else if (!categoryId.isNullOrBlank() && categoryId != "all") {
                    append("category_id=${URLEncoder.encode(categoryId, "UTF-8")}&page=$page&limit=$limit")
                } else {
                    append("page=$page&limit=$limit")
                }
            }
            val raw = executeGet(endpoint).trim()
            val array = extractArray(raw, "prompts", "data", "items", "results")
            val list = mutableListOf<PromptItem>()
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                parsePromptItem(obj)?.let { list.add(it) }
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchPromptDetail(id: String): Result<PromptItem> {
        return try {
            val encodedId = URLEncoder.encode(id, "UTF-8")
            val raw = executeGet("prompt.php?id=$encodedId").trim()
            val obj = if (raw.startsWith("[")) {
                JSONArray(raw).optJSONObject(0) ?: JSONObject()
            } else {
                val root = JSONObject(raw)
                root.optJSONObject("data")
                    ?: root.optJSONArray("data")?.optJSONObject(0)
                    ?: root.optJSONObject("prompt")
                    ?: root.optJSONArray("prompt")?.optJSONObject(0)
                    ?: root.optJSONObject("item")
                    ?: root.optJSONObject("result")
                    ?: root
            }
            val item = parsePromptItem(obj, fallbackId = id)
                ?: throw IllegalStateException("Prompt details unavailable")
            Result.success(item)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun parsePromptItem(obj: JSONObject, fallbackId: String = ""): PromptItem? {
        val id = optStringAny(obj, "id", "prompt_id").ifBlank { fallbackId }
        if (id.isBlank()) return null

        val title = optStringAny(obj, "title", "name", "prompt_title").ifBlank { "AI Prompt #$id" }
        val categoryId = optStringAny(obj, "category_id", "cat_id")
        val rawCategoryName = optStringAny(obj, "category_name", "category", "cat_name", "tag")
            .ifBlank { "Trending Photos" }
        val categoryName = normalizeCategoryName(rawCategoryName)
        val modelName = optStringAny(obj, "model_name", "ai_model", "model", "generator")
            .ifBlank { "AI Model" }

        val rawImage = optStringAny(
            obj,
            "image_url",
            "image",
            "thumbnail",
            "thumbnail_url",
            "thumb",
            "photo_url",
            "preview_url",
            "cover_url",
            "media_url",
            "media"
        )
        val rawVideo = optStringAny(obj, "video_url", "video", "mp4_url", "video_file", "stream_url", "video_link")
        val mediaType = optStringAny(obj, "media_type", "type", "file_type").lowercase()

        val rawResolvedImage = resolveUrl(rawImage)
        var resolvedVideo = resolveUrl(rawVideo)
        val resolvedImage = if (isVideoExtension(rawResolvedImage)) {
            if (resolvedVideo.isBlank()) {
                resolvedVideo = rawResolvedImage
            }
            ""
        } else {
            rawResolvedImage
        }

        val isTrendingVideos = categoryName.equals("Trending Videos", ignoreCase = true)
        val isVideoFlag = isTrendingVideos ||
            (categoryName.contains("video", ignoreCase = true) && (parseBool(obj, "is_video", "has_video") || mediaType == "video" || resolvedVideo.isNotBlank()))

        val promptText = optStringAny(obj, "prompt_text", "prompt", "description", "text", "content")
        val isDaily = parseBool(obj, "is_daily", "is_daily_update", "is_featured", "is_trending")

        return PromptItem(
            id = id,
            title = title,
            categoryId = categoryId,
            categoryName = categoryName,
            modelName = modelName,
            imageUrl = resolvedImage,
            videoUrl = resolvedVideo.ifBlank { null },
            isVideo = isVideoFlag,
            promptText = promptText,
            isDailyUpdate = isDaily,
            aspectRatio = 0.78f
        )
    }

    private fun extractArray(raw: String, vararg keys: String): JSONArray {
        if (raw.startsWith("[")) {
            return JSONArray(raw)
        }
        val obj = JSONObject(raw)
        for (key in keys) {
            val arr = obj.optJSONArray(key)
            if (arr != null) return arr
        }
        // Check nested data.prompts or data.items
        val dataObj = obj.optJSONObject("data")
        if (dataObj != null) {
            for (key in keys) {
                val arr = dataObj.optJSONArray(key)
                if (arr != null) return arr
            }
        }
        return JSONArray()
    }

    private fun optStringAny(obj: JSONObject, vararg keys: String): String {
        for (key in keys) {
            if (obj.has(key) && !obj.isNull(key)) {
                val value = obj.optString(key, "").trim()
                if (value.isNotEmpty() && value != "null") return value
            }
        }
        return ""
    }

    private fun hasAnyKey(obj: JSONObject, vararg keys: String): Boolean {
        return keys.any { obj.has(it) && !obj.isNull(it) }
    }

    private fun parseBool(obj: JSONObject, vararg keys: String): Boolean {
        for (key in keys) {
            if (obj.has(key) && !obj.isNull(key)) {
                val raw = obj.opt(key)
                return when (raw) {
                    is Boolean -> raw
                    is Number -> raw.toInt() == 1
                    is String -> raw.equals("true", ignoreCase = true) || raw == "1" || raw.equals("yes", ignoreCase = true)
                    else -> false
                }
            }
        }
        return false
    }

    private fun resolveUrl(path: String): String {
        val trimmed = path.trim()
        if (trimmed.isBlank()) return ""
        val encoded = trimmed.replace(" ", "%20")
        if (encoded.startsWith("//")) return "https:$encoded"
        if (encoded.startsWith("http://", ignoreCase = true)) {
            return "https://" + encoded.substring(7)
        }
        if (encoded.startsWith("https://", ignoreCase = true)) {
            return encoded
        }
        val cleaned = encoded.trimStart('/')
        return "$SITE_ROOT$cleaned"
    }

    private fun isVideoExtension(url: String): Boolean {
        val pathOnly = url.lowercase().substringBefore('?').substringBefore('#')
        return pathOnly.endsWith(".mp4") || pathOnly.endsWith(".webm") || pathOnly.endsWith(".mov") || pathOnly.endsWith(".m3u8")
    }
}
