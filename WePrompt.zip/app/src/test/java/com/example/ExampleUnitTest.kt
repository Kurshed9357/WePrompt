package com.example

import com.example.data.CategoryItem
import com.example.data.PromptItem
import com.example.data.PromptRepository
import com.example.data.WePromptApiClient
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun testDynamicViewCountFormatting() {
    assertEquals("10K", PromptRepository.formatViewCount(10_000))
    assertEquals("12.5K", PromptRepository.formatViewCount(12_500))
    assertEquals("500K", PromptRepository.formatViewCount(500_000))
    assertEquals("1M", PromptRepository.formatViewCount(1_000_000))
    assertEquals("1M", PromptRepository.formatViewCount(1_500_000))
  }

  @Test
  fun testPromptItemCreation() {
    val cat = CategoryItem(id = "1", name = "Trending Photos")
    val item = PromptItem(
      id = "test_1",
      title = "Cybernetic Portrait",
      categoryId = cat.id,
      categoryName = cat.name,
      modelName = "Midjourney v6.1",
      imageUrl = "https://prompt.wegocup.com/uploads/sample.webp",
      isVideo = false,
      promptText = "A futuristic cybernetic portrait",
      viewsCount = 42_500
    )
    assertEquals("test_1", item.id)
    assertEquals("Cybernetic Portrait", item.title)
    assertEquals("Trending Photos", item.categoryName)
    assertEquals("Midjourney v6.1", item.modelName)
    assertFalse(item.isVideo)
  }

  @Test
  fun testCategoryNormalizationAndOrdering() {
    val raw = listOf(
      CategoryItem(id = "3", name = "Boys", slug = "boys"),
      CategoryItem(id = "4", name = "Girls", slug = "girls"),
      CategoryItem(id = "1", name = WePromptApiClient.normalizeCategoryName("Tending Photos", "tending-photos"), slug = "tending-photos"),
      CategoryItem(id = "2", name = WePromptApiClient.normalizeCategoryName("Tending Videos", "tending-videos"), slug = "tending-videos")
    )
    val sorted = WePromptApiClient.sortCategories(raw)
    assertEquals(
      listOf("Trending Photos", "Trending Videos", "Boys", "Girls"),
      sorted.map { it.name }
    )
  }
}
