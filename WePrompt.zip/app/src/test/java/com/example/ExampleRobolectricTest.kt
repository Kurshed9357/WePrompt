package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.PromptItem
import com.example.data.PromptRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("WePrompt", appName)
  }

  @Test
  fun `verify dynamic view count range and refresh increment cap`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = PromptRepository(context)

    val initial = repository.resolveDynamicViewCount("test_prompt_views", isRefresh = false)
    assertTrue(initial in PromptRepository.MIN_INITIAL_VIEWS..PromptRepository.MAX_INITIAL_VIEWS)

    val refreshed = repository.resolveDynamicViewCount("test_prompt_views", isRefresh = true)
    val diff = refreshed - initial
    assertTrue(diff in PromptRepository.MIN_REFRESH_INCREMENT..PromptRepository.MAX_REFRESH_INCREMENT)
    assertTrue(refreshed <= PromptRepository.MAX_VIEW_CAP)
  }

  @Test
  fun `verify toggle favorites persistence`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repository = PromptRepository(context)

    val item = PromptItem(
      id = "fav_test_1",
      title = "Neon City",
      categoryName = "Trending Photos",
      modelName = "FLUX.1",
      imageUrl = "https://prompt.wegocup.com/test.jpg",
      promptText = "Neon city prompt"
    )
    val initialFav = repository.isFavorite(item.id)
    repository.toggleFavorite(item)
    assertEquals(!initialFav, repository.isFavorite(item.id))

    repository.toggleFavorite(item)
    assertEquals(initialFav, repository.isFavorite(item.id))
  }
}
